# Sales Data Analysis Dashboard

A beginner-friendly Python project that analyzes sales data and displays an interactive dashboard. It uses **Python, Pandas, Streamlit, and Plotly**.

## Dashboard features

- KPI cards: total sales, total profit, unique orders, quantity sold, and profit margin
- Date, region, category, and payment-mode filters
- Monthly sales trend
- Sales by category and region
- Top 10 products by sales
- Sales share by payment mode
- Category performance table
- View and download the filtered records as CSV

## Folder structure

```text
Sales_Data_Analysis_Dashboard/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
└── data/
    ├── sales_data.csv
    └── original_sales_workbook.xlsx
```

## Dataset

The dataset was prepared from the `Sales_Data` sheet in the supplied workbook. It includes order ID, order date, region, state, category, product, sales, profit, quantity, and payment mode.

## Run the dashboard on your computer

### 1. Install Python

Install Python 3.10 or newer from https://www.python.org/downloads/. During installation on Windows, select **Add Python to PATH** if that option appears.

### 2. Download or extract the project

Download the project ZIP from GitHub or this chat, then extract it. Open the extracted `Sales_Data_Analysis_Dashboard` folder.

### 3. Open a terminal in the project folder

On Windows, open the folder in File Explorer, click the address bar, type `cmd`, and press Enter. You can also use the terminal in VS Code.

### 4. Create a virtual environment (recommended)

```bash
python -m venv .venv
```

Activate it on Windows:

```bash
.venv\Scripts\activate
```

On macOS/Linux:

```bash
source .venv/bin/activate
```

### 5. Install the required libraries

```bash
python -m pip install -r requirements.txt
```

### 6. Start the dashboard

```bash
streamlit run app.py
```

Streamlit should open the dashboard in your browser. If it does not, copy the local URL printed in the terminal (usually `http://localhost:8501`) into your browser.

To stop the dashboard, return to the terminal and press `Ctrl+C`.

## Upload this project to GitHub (beginner steps)

1. Go to https://github.com/ and sign in or create an account.
2. Click the **+** button in the top-right corner and choose **New repository**.
3. Repository name: `sales-data-analysis-dashboard`.
4. Add this description: `Interactive sales dashboard built with Python, Pandas, Streamlit and Plotly`.
5. Choose **Public** if you want recruiters to see the project. Check that you have permission to share the data.
6. Click **Create repository**.
7. On the new repository page, select **Add file → Upload files**.
8. Open the extracted project folder on your computer. Upload `app.py`, `requirements.txt`, `README.md`, `.gitignore`, and the `data` folder (including both files).
9. Enter a commit message such as `Add sales analysis dashboard project`.
10. Click **Commit changes**.

Important: upload the *contents* of the project folder, not only the ZIP file. GitHub will display the README on the repository home page.

## Optional: publish a live dashboard

GitHub stores the code and data; it does not run the Streamlit app by itself. To publish an interactive live version, you can connect this repository to Streamlit Community Cloud at https://share.streamlit.io/ and select `app.py` as the main file. Check the platform's current account, privacy, and deployment requirements first.

## Metrics

- **Total sales**: sum of the Sales column
- **Total profit**: sum of the Profit column
- **Unique orders**: count of distinct Order ID values
- **Units sold**: sum of Quantity
- **Profit margin**: total profit divided by total sales

## Skills demonstrated

Python, Pandas, data cleaning, aggregation, data visualization, Streamlit, Plotly, CSV/Excel handling, GitHub documentation.
