import streamlit as st
import pandas as pd
import plotly.express as px
from pathlib import Path

# ----------------------------
# Page setup
# ----------------------------
st.set_page_config(
    page_title="Sales Data Analysis Dashboard",
    page_icon="📊",
    layout="wide",
)

st.title("📊 Sales Data Analysis Dashboard")
st.caption("Explore sales, profit, products, categories, regions, and payment methods.")

# ----------------------------
# Load the dataset
# ----------------------------
DATA_PATH = Path(__file__).parent / "data" / "sales_data.csv"

@st.cache_data
def load_data(path):
    data = pd.read_csv(path)
    data["Order Date"] = pd.to_datetime(data["Order Date"], errors="coerce")
    for col in ["Sales", "Profit", "Quantity"]:
        data[col] = pd.to_numeric(data[col], errors="coerce")
    data = data.dropna(subset=["Order Date", "Sales", "Profit"])
    return data

try:
    df = load_data(DATA_PATH)
except FileNotFoundError:
    st.error("Could not find data/sales_data.csv. Please keep the data folder next to app.py.")
    st.stop()

if df.empty:
    st.warning("The dataset is empty or its date/sales/profit columns could not be read.")
    st.stop()

# ----------------------------
# Sidebar filters
# ----------------------------
st.sidebar.header("Filter the data")

min_date = df["Order Date"].min().date()
max_date = df["Order Date"].max().date()
date_range = st.sidebar.date_input(
    "Order date range",
    value=(min_date, max_date),
    min_value=min_date,
    max_value=max_date,
)

regions = sorted(df["Region"].dropna().astype(str).unique())
selected_regions = st.sidebar.multiselect("Region", regions, default=regions)

categories = sorted(df["Category"].dropna().astype(str).unique())
selected_categories = st.sidebar.multiselect("Category", categories, default=categories)

payment_modes = sorted(df["Payment Mode"].dropna().astype(str).unique())
selected_payments = st.sidebar.multiselect("Payment mode", payment_modes, default=payment_modes)

filtered = df.copy()
if isinstance(date_range, (tuple, list)) and len(date_range) == 2:
    start_date, end_date = date_range
    filtered = filtered[
        (filtered["Order Date"].dt.date >= start_date)
        & (filtered["Order Date"].dt.date <= end_date)
    ]
if selected_regions:
    filtered = filtered[filtered["Region"].isin(selected_regions)]
else:
    filtered = filtered.iloc[0:0]
if selected_categories:
    filtered = filtered[filtered["Category"].isin(selected_categories)]
else:
    filtered = filtered.iloc[0:0]
if selected_payments:
    filtered = filtered[filtered["Payment Mode"].isin(selected_payments)]
else:
    filtered = filtered.iloc[0:0]

# ----------------------------
# KPI cards
# ----------------------------
total_sales = filtered["Sales"].sum()
total_profit = filtered["Profit"].sum()
total_orders = filtered["Order ID"].nunique()
total_quantity = filtered["Quantity"].sum()
profit_margin = total_profit / total_sales if total_sales else 0

def money(value):
    return f"₹{value:,.0f}"

k1, k2, k3, k4, k5 = st.columns(5)
k1.metric("Total sales", money(total_sales))
k2.metric("Total profit", money(total_profit))
k3.metric("Unique orders", f"{total_orders:,}")
k4.metric("Units sold", f"{total_quantity:,.0f}")
k5.metric("Profit margin", f"{profit_margin:.1%}")

st.divider()

if filtered.empty:
    st.info("No records match these filters. Try selecting more regions, categories, payment methods, or dates.")
    st.stop()

# ----------------------------
# Charts
# ----------------------------
left, right = st.columns(2)

monthly = (
    filtered.assign(Month=filtered["Order Date"].dt.to_period("M").astype(str))
    .groupby("Month", as_index=False)
    .agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"))
    .sort_values("Month")
)
with left:
    st.subheader("Monthly sales trend")
    fig_month = px.line(
        monthly, x="Month", y="Sales", markers=True,
        title="Sales by month", labels={"Sales": "Sales (₹)", "Month": "Month"}
    )
    st.plotly_chart(fig_month, use_container_width=True)

category = (
    filtered.groupby("Category", as_index=False)
    .agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"))
    .sort_values("Sales", ascending=False)
)
with right:
    st.subheader("Sales by category")
    fig_category = px.bar(
        category, x="Category", y="Sales", color="Category",
        title="Sales by product category", labels={"Sales": "Sales (₹)"}
    )
    st.plotly_chart(fig_category, use_container_width=True)

left2, right2 = st.columns(2)
region = (
    filtered.groupby("Region", as_index=False)
    .agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"))
    .sort_values("Sales", ascending=False)
)
with left2:
    st.subheader("Sales by region")
    fig_region = px.bar(
        region, x="Region", y="Sales", color="Region",
        title="Sales by region", labels={"Sales": "Sales (₹)"}
    )
    st.plotly_chart(fig_region, use_container_width=True)

product = (
    filtered.groupby("Product", as_index=False)
    .agg(Sales=("Sales", "sum"), Profit=("Profit", "sum"), Quantity=("Quantity", "sum"))
    .sort_values("Sales", ascending=False)
    .head(10)
)
with right2:
    st.subheader("Top 10 products")
    fig_product = px.bar(
        product.sort_values("Sales"), x="Sales", y="Product", orientation="h",
        title="Top 10 products by sales", labels={"Sales": "Sales (₹)"}
    )
    st.plotly_chart(fig_product, use_container_width=True)

left3, right3 = st.columns(2)
payment = (
    filtered.groupby("Payment Mode", as_index=False)
    .agg(Sales=("Sales", "sum"), Orders=("Order ID", "nunique"))
    .sort_values("Sales", ascending=False)
)
with left3:
    st.subheader("Sales by payment mode")
    fig_payment = px.pie(
        payment, names="Payment Mode", values="Sales", hole=0.45,
        title="Share of sales by payment mode"
    )
    st.plotly_chart(fig_payment, use_container_width=True)

with right3:
    st.subheader("Category performance table")
    display_category = category.copy()
    display_category["Sales"] = display_category["Sales"].map(money)
    display_category["Profit"] = display_category["Profit"].map(money)
    st.dataframe(display_category, use_container_width=True, hide_index=True)

# ----------------------------
# Download filtered data
# ----------------------------
st.subheader("Filtered records")
st.write(f"Showing **{len(filtered):,}** rows after applying your filters.")
st.dataframe(filtered, use_container_width=True, hide_index=True)

csv_bytes = filtered.to_csv(index=False).encode("utf-8")
st.download_button(
    label="⬇️ Download filtered data as CSV",
    data=csv_bytes,
    file_name="filtered_sales_data.csv",
    mime="text/csv",
)
